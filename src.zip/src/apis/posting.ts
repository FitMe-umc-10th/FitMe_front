import axios from 'axios';
import type {
  GetClosingSoonPostingsParams,
  GetHomePostingListParams,
  GetRecentViewedPostingsParams,
  GetSavedPostingsParams,
  HomePostingFeed,
  Posting,
  PostingType,
  RecentViewedPostingFeed,
} from '@/types/posting';
import { axiosInstance } from '@/apis/axiosInstance';
import {
  type ApiClosingSoonPostingsResponse,
  type ApiPostingApplication,
  type ApiPostingDetail,
  type ApiPopularPostingsResponse,
  type ApiRecentViewedPostingsResponse,
  type ApiSavedPostMutationPayload,
  type ApiSavedPostingsPayload,
  type PostingApplicationResult,
  getSavedIdFromPayload,
  mapApiPostingApplication,
  mapApiPostingDetailToPosting,
  mapApiPostingList,
  mapApiSavedPostingList,
  mapApiSavedPostingToPosting,
  normalizeSavedPostingsPayload,
  type ApiSavedPosting,
} from '@/apis/postingMapper';
import type { ApiResponse } from '@/types/common';
import { unwrapApiData } from '@/shared/utils/api';

export type { PostingApplicationResult, PostingApplicationStatus } from '@/apis/postingMapper';

const DEFAULT_HOME_POPULAR_SIZE = 8;
const DEFAULT_HOME_RECENT_VIEWED_SIZE = 10;
const DEFAULT_HOME_CLOSING_SOON_SIZE = 5;

const POSTS_ENDPOINT = '/api/v1/posts';
const SAVED_POSTS_ENDPOINT = '/api/v1/saved-posts';
const USER_APPLICATIONS_ENDPOINT = '/api/v1/user-applications';

export interface ToggleSaveResult {
  isSaved: boolean;
  savedId?: number;
}

const fetchSavedPostings = async (params: GetSavedPostingsParams = {}) => {
  const { data } = await axiosInstance.get<ApiResponse<ApiSavedPostingsPayload> | ApiSavedPostingsPayload>(
    SAVED_POSTS_ENDPOINT,
    {
      params,
    },
  );

  return normalizeSavedPostingsPayload(unwrapApiData<ApiSavedPostingsPayload>(data));
};

const findSavedIdByPostingId = async (postingId: number) => {
  const savedPostings = await fetchSavedPostings({
    category: 'ALL',
    sort: 'DEADLINE',
    size: 100,
  });
  const savedPosting = savedPostings.find((posting) => posting.postId === postingId || posting.id === postingId);

  return savedPosting?.savedId;
};

const getPostingDetailByType = async (postingId: number, type: PostingType): Promise<Posting> => {
  const endpoint =
    type === 'SCHOLARSHIP'
      ? `${POSTS_ENDPOINT}/scholarship/${postingId}`
      : `${POSTS_ENDPOINT}/contests/${postingId}`;
  const { data } = await axiosInstance.get(endpoint);

  return mapApiPostingDetailToPosting(unwrapApiData<ApiPostingDetail>(data), type);
};

const isNotFoundError = (error: unknown) => axios.isAxiosError(error) && error.response?.status === 404;

const getSettledPostings = (result: PromiseSettledResult<Posting[]>) =>
  result.status === 'fulfilled' ? result.value : [];

type HomePostingFeedResults = readonly [
  PromiseSettledResult<Posting[]>,
  PromiseSettledResult<RecentViewedPostingFeed>,
  PromiseSettledResult<Posting[]>,
  PromiseSettledResult<Posting[]>,
];

const throwIfEveryPostingRequestFailed = (results: readonly PromiseSettledResult<unknown>[]) => {
  const firstRejectedResult = results.find((result) => result.status === 'rejected');

  if (results.every((result) => result.status === 'rejected') && firstRejectedResult?.status === 'rejected') {
    throw firstRejectedResult.reason;
  }
};

const mapHomePostingFeedResults = ([
  popularResult,
  recentViewedResult,
  scholarshipDeadlineResult,
  contestDeadlineResult,
]: HomePostingFeedResults): HomePostingFeed => ({
  popularPostings: getSettledPostings(popularResult),
  recentViewedName: recentViewedResult.status === 'fulfilled' ? recentViewedResult.value.name : '',
  recentViewedPostings:
    recentViewedResult.status === 'fulfilled' ? recentViewedResult.value.postings : [],
  deadlinePostings: {
    SCHOLARSHIP: getSettledPostings(scholarshipDeadlineResult),
    CONTEST: getSettledPostings(contestDeadlineResult),
  },
});

export const getPopularPostings = async ({
  cursor,
  size = DEFAULT_HOME_POPULAR_SIZE,
}: GetHomePostingListParams = {}): Promise<Posting[]> => {
  const { data } = await axiosInstance.get(`${POSTS_ENDPOINT}/popular`, {
    params: {
      cursor,
      size,
    },
  });
  const result = unwrapApiData<ApiPopularPostingsResponse>(data);

  return mapApiPostingList(result.posts ?? result.popularPosts ?? []);
};

export const getRecentViewedPostings = async ({
  page = 0,
  size = DEFAULT_HOME_RECENT_VIEWED_SIZE,
}: GetRecentViewedPostingsParams = {}): Promise<RecentViewedPostingFeed> => {
  const { data } = await axiosInstance.get(`${POSTS_ENDPOINT}/recent-views`, {
    params: {
      page,
      size,
    },
  });
  const result = unwrapApiData<ApiRecentViewedPostingsResponse>(data);

  return {
    name: result.name,
    postings: mapApiPostingList(result.posts ?? []),
  };
};

export const getClosingSoonPostings = async ({
  type,
  sort = 'FIT',
  size = DEFAULT_HOME_CLOSING_SOON_SIZE,
}: GetClosingSoonPostingsParams): Promise<Posting[]> => {
  const { data } = await axiosInstance.get(`${POSTS_ENDPOINT}/closing-soon`, {
    params: {
      postType: type === 'ALL' ? undefined : type,
      sort,
      size,
    },
  });
  const result = unwrapApiData<ApiClosingSoonPostingsResponse>(data);

  return mapApiPostingList(result ?? []);
};

export const getHomePostingFeed = async (): Promise<HomePostingFeed> => {
  const homePostingRequests = [
    getPopularPostings({ size: DEFAULT_HOME_POPULAR_SIZE }),
    getRecentViewedPostings({ page: 0, size: DEFAULT_HOME_RECENT_VIEWED_SIZE }),
    getClosingSoonPostings({
      type: 'SCHOLARSHIP',
      size: DEFAULT_HOME_CLOSING_SOON_SIZE,
    }),
    getClosingSoonPostings({
      type: 'CONTEST',
      size: DEFAULT_HOME_CLOSING_SOON_SIZE,
    }),
  ] as const;
  const results = await Promise.allSettled(homePostingRequests);

  throwIfEveryPostingRequestFailed(results);

  return mapHomePostingFeedResults(results);
};

export const getSavedPostings = async ({
  category = 'ALL',
  sort = 'DEADLINE',
  cursor,
  size,
}: GetSavedPostingsParams = {}): Promise<Posting[]> => {
  const savedPostings = await fetchSavedPostings({ category, sort, cursor, size });

  return mapApiSavedPostingList(savedPostings);
};

const getPostingDetailLookupOrder = (preferredType?: PostingType): PostingType[] => {
  if (preferredType === 'CONTEST') return ['CONTEST', 'SCHOLARSHIP'];
  return ['SCHOLARSHIP', 'CONTEST'];
};

export const getPostingById = async (
  postingId: number,
  preferredType?: PostingType,
): Promise<Posting | null> => {
  for (const postingType of getPostingDetailLookupOrder(preferredType)) {
    try {
      return await getPostingDetailByType(postingId, postingType);
    } catch (error) {
      if (!isNotFoundError(error)) throw error;
    }
  }

  return null;
};

export const startPostingApplication = async (
  postingId: number,
): Promise<PostingApplicationResult> => {
  const { data } = await axiosInstance.patch<ApiResponse<ApiPostingApplication> | ApiPostingApplication>(
    `${POSTS_ENDPOINT}/${postingId}/application`,
  );

  return mapApiPostingApplication(unwrapApiData<ApiPostingApplication>(data));
};

export const completePostingApplication = async (
  userApplicationId: number,
): Promise<PostingApplicationResult> => {
  const { data } = await axiosInstance.patch<ApiResponse<ApiPostingApplication> | ApiPostingApplication>(
    `${USER_APPLICATIONS_ENDPOINT}/${userApplicationId}/status`,
    { status: 'PENDING_RESULT' },
  );

  return mapApiPostingApplication(unwrapApiData<ApiPostingApplication>(data));
};

export const toggleSave = async (
  postingId: number,
  isSaved: boolean,
  savedId?: number,
): Promise<ToggleSaveResult> => {
  if (isSaved) {
    const targetSavedId = savedId ?? (await findSavedIdByPostingId(postingId));

    if (!targetSavedId) {
      throw new Error('저장 해제에 필요한 savedId가 없습니다.');
    }

    const { data } = await axiosInstance.delete<ApiResponse<ApiSavedPosting> | ApiSavedPosting>(
      `${SAVED_POSTS_ENDPOINT}/${targetSavedId}`,
    );
    const deletedPosting = unwrapApiData<ApiSavedPostMutationPayload>(data);

    return {
      isSaved: false,
      savedId: getSavedIdFromPayload(deletedPosting, targetSavedId),
    };
  }

  const { data } = await axiosInstance.post<ApiResponse<ApiSavedPosting> | ApiSavedPosting>(
    SAVED_POSTS_ENDPOINT,
    { postId: postingId },
  );
  const savedPostingPayload = unwrapApiData<ApiSavedPosting>(data);
  const savedPosting = mapApiSavedPostingToPosting(savedPostingPayload);

  return {
    isSaved: true,
    savedId: getSavedIdFromPayload(savedPostingPayload, savedPosting.savedId),
  };
};
